package com.telematica.meteoapp

import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay

class MapaCalorActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private var capaActual: TilesOverlay? = null
    private var tileProviderActual: org.osmdroid.tileprovider.MapTileProviderBasic? = null

    companion object {
        private const val TAG = "MapaCalorActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurar OSMDroid
        Configuration.getInstance().load(
            this,
            PreferenceManager.getDefaultSharedPreferences(this)
        )
        Configuration.getInstance().userAgentValue = packageName

        // IMPORTANTE: Desactivar caché para capas meteorológicas
        Configuration.getInstance().expirationExtendedDuration = 0L
        Configuration.getInstance().expirationOverrideDuration = 0L

        setContentView(R.layout.activity_mapa_calor)

        mapView = findViewById(R.id.mapView)
        configurarMapa()

        // Configurar botones
        findViewById<Button>(R.id.btnNubes).setOnClickListener {
            cambiarCapa("clouds_new", "Nubes")
        }

        findViewById<Button>(R.id.btnTemperatura).setOnClickListener {
            cambiarCapa("temp_new", "Temperatura")
        }

        findViewById<Button>(R.id.btnPrecipitacion).setOnClickListener {
            cambiarCapa("precipitation_new", "Precipitación")
        }

        // Cargar capa inicial
        cambiarCapa("clouds_new", "Nubes")
    }

    private fun configurarMapa() {
        // Usar OpenStreetMap como mapa base
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.setBuiltInZoomControls(false)

        val mapController = mapView.controller
        mapController.setZoom(6.0)

        // Centrar en España
        val startPoint = GeoPoint(40.4168, -3.7038)
        mapController.setCenter(startPoint)

        mapView.minZoomLevel = 2.0
        mapView.maxZoomLevel = 18.0

        // Habilitar rotación y gestos
        mapView.setMultiTouchControls(true)
    }

    private fun cambiarCapa(nuevaCapa: String, nombreCapa: String) {
        Log.d(TAG, "Cambiando a capa: $nuevaCapa")

        // Eliminar TODAS las capas overlay (excepto el mapa base)
        val overlaysToRemove = mapView.overlays.filterIsInstance<TilesOverlay>().toList()
        overlaysToRemove.forEach { overlay ->
            mapView.overlays.remove(overlay)
        }

        // Detener y limpiar el proveedor de tiles anterior
        tileProviderActual?.let { provider ->
            provider.detach()
            provider.clearTileCache()
        }

        // Limpiar referencias
        capaActual = null
        tileProviderActual = null

        Log.d(TAG, "Todas las capas eliminadas. Overlays restantes: ${mapView.overlays.size}")

        try {
            // Crear nueva capa meteorológica
            val weatherTileSource = WeatherTileSource(nuevaCapa)
            val tileProvider = org.osmdroid.tileprovider.MapTileProviderBasic(
                applicationContext,
                weatherTileSource
            )

            // Limpiar caché antes de crear la nueva capa
            tileProvider.clearTileCache()

            val tilesOverlay = TilesOverlay(tileProvider, this)
            tilesOverlay.loadingBackgroundColor = android.graphics.Color.TRANSPARENT
            tilesOverlay.setColorFilter(null)

            // Guardar referencias
            tileProviderActual = tileProvider
            capaActual = tilesOverlay

            // Añadir la nueva capa
            mapView.overlays.add(tilesOverlay)

            // Refrescar mapa de forma más agresiva
            mapView.invalidate()
            mapView.postInvalidate()

            // Forzar recarga de tiles visibles
            mapView.zoomController?.activate()

            Toast.makeText(this, "Capa: $nombreCapa", Toast.LENGTH_SHORT).show()
            Log.d(TAG, "Capa $nuevaCapa añadida. Total overlays: ${mapView.overlays.size}")

        } catch (e: Exception) {
            Log.e(TAG, "Error al cambiar capa: ${e.message}", e)
            Toast.makeText(this, "Error al cargar capa: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDetach()
    }
}

class WeatherTileSource(private val operacion: String) :
    org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase(
        "WeatherTiles",
        0, 18, 1024, "",  // Sin extensión porque la añadimos en la URL
        arrayOf("")  // Base URL vacía, la construimos completa
    ) {

    companion object {
        private const val TAG = "WeatherTileSource"
        private const val BASE_URL = "https://mapas-bqfqfpc7h6avb6bv.spaincentral-01.azurewebsites.net"
    }

    override fun getTileURLString(pMapTileIndex: Long): String {
        val zoom = org.osmdroid.util.MapTileIndex.getZoom(pMapTileIndex)
        val x = org.osmdroid.util.MapTileIndex.getX(pMapTileIndex)
        val y = org.osmdroid.util.MapTileIndex.getY(pMapTileIndex)

        val url = "$BASE_URL/api/get_map?op=$operacion&z=$zoom&x=$x&y=$y"
        Log.d(TAG, "URL del tile: $url")

        return url
    }
}