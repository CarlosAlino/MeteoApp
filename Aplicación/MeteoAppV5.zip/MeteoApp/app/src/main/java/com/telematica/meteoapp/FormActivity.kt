package com.telematica.meteoapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import java.security.MessageDigest
import java.util.Base64

//import com.google.firebase.firestore.ktx.firestore

class FormActivity : AppCompatActivity() {

    private val db = Firebase.firestore   // Firestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form)

        val email = findViewById<EditText>(R.id.editTextEmail)
        val password = findViewById<EditText>(R.id.editTextPassword)
        val button = findViewById<Button>(R.id.buttonSubmit)
        val botonRegistro = findViewById<Button>(R.id.bottonRegistro)
        val btnToggle = findViewById<Button>(R.id.btnTogglePassword)

        btnToggle.setOnClickListener {
            if (password.inputType == android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                // 🔹 Mostrar texto normal
                password.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                btnToggle.text = "Ocultar"
            } else {
                // 🔹 Volver a puntos
                password.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                btnToggle.text = "Mostrar"
            }

            // Mantener el cursor al final del texto
            password.setSelection(password.text.length)
        }

        // LOGIN
        button.setOnClickListener {
            val emailText = email.text.toString().trim()
            val passwordText = password.text.toString().trim()

            if (emailText.isEmpty() || passwordText.isEmpty()) {
                Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            db.collection("usuarios")
                .whereEqualTo("email", emailText)
                .get()
                .addOnSuccessListener { result ->
                    if (result.isEmpty) {
                        Toast.makeText(this, "Usuario no existe", Toast.LENGTH_SHORT).show()
                    } else {
                        val user = result.documents[0]

                        // 🔹 Recuperar hash y salt almacenados
                        val storedHash = user.getString("password")
                        val storedSalt = user.getString("salt")

                        if (storedHash == null || storedSalt == null) {
                            Toast.makeText(this, "Error: datos de usuario corruptos", Toast.LENGTH_SHORT).show()
                            return@addOnSuccessListener
                        }

                        // 🔹 Recalcular hash con el salt almacenado
                        val recalculatedHash = hashPassword(passwordText, storedSalt)

                        // 🔹 Comparar hashes
                        if (storedHash == recalculatedHash) {
                            Toast.makeText(this, "Inicio de sesión correcto", Toast.LENGTH_SHORT).show()

                            val Usuariopremium = user.getBoolean("premium")

                            if (Usuariopremium == true) {
                                val intent = Intent(this, MetereologiaPremiumActivity::class.java)
                                intent.putExtra("userName", user.getString("nombre"))
                                intent.putExtra("email", user.getString("email"))
                                intent.putExtra("pais", user.getString("pais"))
                                intent.putExtra("comunidadAutonoma", user.getString("comunidadAutonoma"))
                                intent.putExtra("localidad", user.getString("localidad"))
                                intent.putExtra("municipio", user.getString("municipio"))
                                startActivity(intent)
                                finish()
                            } else {
                                val intent = Intent(this, MetereologiaBasicActivity::class.java)
                                intent.putExtra("userName", user.getString("nombre"))
                                intent.putExtra("email", user.getString("email"))
                                intent.putExtra("pais", user.getString("pais"))
                                intent.putExtra("comunidadAutonoma", user.getString("comunidadAutonoma"))
                                intent.putExtra("localidad", user.getString("localidad"))
                                intent.putExtra("municipio", user.getString("municipio"))
                                startActivity(intent)
                                finish()
                            }

                        } else {
                            Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error al iniciar sesión: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }



        botonRegistro.setOnClickListener {
            val intent = Intent(this, RegistroActivity::class.java)
            startActivity(intent)
        }
    }
    fun hashPassword(password: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val combinado = password + salt
        val hashBytes = md.digest(combinado.toByteArray())
        return Base64.getEncoder().encodeToString(hashBytes)
    }
}
