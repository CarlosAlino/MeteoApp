package com.telematica.meteoapp

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

class MetereologiaPremiumActivity : AppCompatActivity() {
    private var email: String = ""
    private var municipio: String = ""
    private var pais: String = ""
    private var localidad: String = ""
    private var comunidadAutonoma = ""

    private lateinit var menuIcon: ImageView
    private lateinit var textViewWelcome: TextView
    private lateinit var textViewTemperature: TextView
    private lateinit var textViewTemperatureMax: TextView
    private lateinit var textViewTemperatureMin: TextView
    private lateinit var textViewHumedad: TextView
    private lateinit var textViewPresion: TextView

    private lateinit var humidityCircle: CirculoHumedadActivity


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_metereologia_premium)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        humidityCircle = findViewById(R.id.humidityCircle)

        // 🔹 Referencias a los TextViews
        textViewWelcome = findViewById(R.id.textViewWelcome)
        textViewTemperature = findViewById(R.id.textViewTemperature)
        textViewTemperatureMax = findViewById(R.id.textViewTemperatureMax)
        textViewTemperatureMin = findViewById(R.id.textViewTemperatureMin)
        textViewHumedad = findViewById(R.id.textViewValorHumedad)
        textViewPresion = findViewById(R.id.textViewValorPresion)
        menuIcon = findViewById<ImageView>(R.id.menuIcon)
        //textViewQNH = findViewById(R.id.textViewQNH)

        // 🔹 Recibir nombre del usuario desde FormActivity
        val userName = intent.getStringExtra("userName") ?: "Piloto"
        email = intent.getStringExtra("email") ?: ""
        municipio = intent.getStringExtra("municipio") ?: "Desconocido"
        pais = intent.getStringExtra("pais") ?: "Desconocido"

        textViewWelcome.text = "Bienvenido, $userName"

        // 🔹 Mostrar datos meteorológicos simulados
        solicitarDatosMetereológicos()
        mostrarDatosMeteorologicos()

        menuIcon.setOnClickListener { showMenu() }
    }

    private fun solicitarDatosMetereológicos() {

        // Instancia de Firestore
        val db = Firebase.firestore

        // Referencia: /municipio/Actual
        db.collection(municipio)
            .document("Actual")
            .get()
            .addOnSuccessListener { document ->

                if (document != null && document.exists()) {

                    val temperatura = document.getDouble("temperature") ?: 0.0
                    val humedad = document.getLong("humidity")?.toInt() ?: 0

                    // Mostrar valores en la UI
                    textViewTemperature.text = "${temperatura} °C"
                    textViewHumedad.text = "$humedad %"
                    humidityCircle.setPercentage(humedad)   // Actualiza tu círculo

                } else {
                    textViewTemperature.text = "--"
                    textViewHumedad.text = "--"
                }
            }
            .addOnFailureListener {
                textViewTemperature.text = "ERR"
                textViewHumedad.text = "ERR"
            }
    }

    private fun mostrarDatosMeteorologicos() {
        // Por ahora generamos datos aleatorios simulando temperatura y QNH
        val tempMax = 36        // °C
        val tempMin = 28        // °C
        val Presion = 1013
        textViewTemperatureMax.text = "$tempMax °C"
        textViewTemperatureMin.text = "$tempMin °C"
        textViewPresion.text = "$Presion hPa"

    }

    private fun showMenu() {
        val popup = PopupMenu(this, menuIcon)
        popup.menuInflater.inflate(R.menu.menu_main, popup.menu)

        popup.setOnMenuItemClickListener { item ->
            when(item.itemId) {
                R.id.menu_perfil -> {
                    startActivity(Intent(this, PerfilUsuarioActivity::class.java))
                    true
                }
                R.id.menu_cambio_region -> {
                    val intentCambioRegion = Intent(this, UbicacionUsuario::class.java)
                    intentCambioRegion.putExtra("email", email) // 'email' es la variable de clase que recibiste de FormActivity
                    intentCambioRegion.putExtra("municipio",municipio)
                    intentCambioRegion.putExtra("pais",pais)
                    intentCambioRegion.putExtra("comunidadAutonoma",comunidadAutonoma)
                    intentCambioRegion.putExtra("localidad",localidad)
                    startActivity(intentCambioRegion)
                    true
                }
                R.id.menu_mapa_metereologico -> {
                    startActivity(Intent(this, DecisionMapaMetereologicoActivity::class.java))
                    true
                }
                R.id.menu_ex3 -> {
                    startActivity(Intent(this, PerfilUsuarioActivity::class.java))
                    true
                }
                else -> false
            }
        }

        popup.show()
    }


}
