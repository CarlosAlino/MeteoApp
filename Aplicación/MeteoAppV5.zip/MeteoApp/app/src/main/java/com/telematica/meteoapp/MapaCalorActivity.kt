package com.telematica.meteoapp

import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.TilesOverlay

class MapaCalorActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private var capaActual: TilesOverlay? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configurar OSMDroid
        Configuration.getInstance().load(
            this,
            PreferenceManager.getDefaultSharedPreferences(this)
        )
        Configuration.getInstance().userAgentValue = packageName

        setContentView(R.layout.activity_mapa_calor)

        mapView = findViewById(R.id.mapView)
        configurarMapa()

        // Configurar botones
        findViewById<Button>(R.id.btnNubes).setOnClickListener {
            cambiarCapa("TA2") // Nubes
        }

        findViewById<Button>(R.id.btnTemperatura).setOnClickListener {
            cambiarCapa("temp_new") // Temperatura
        }

        findViewById<Button>(R.id.btnPrecipitacion).setOnClickListener {
            cambiarCapa("precipitation_new") // Precipitación
        }

        // Cargar capa inicial
        cambiarCapa("TA2")
    }

    private fun configurarMapa() {
        // Usar OpenStreetMap como mapa base
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.setBuiltInZoomControls(false)

        val mapController = mapView.controller
        mapController.setZoom(5.0)

        // Centrar en España
        val startPoint = GeoPoint(40.4168, -3.7038)
        mapController.setCenter(startPoint)

        mapView.minZoomLevel = 2.0
        mapView.maxZoomLevel = 18.0

        // Habilitar rotación y gestos
        mapView.setMultiTouchControls(true)
    }

    private fun cambiarCapa(nuevaCapa: String) {
        // Eliminar capa anterior si existe
        capaActual?.let {
            mapView.overlays.remove(it)
        }

        // Crear nueva capa meteorológica
        val weatherTileSource = WeatherTileSource(nuevaCapa)
        val tileProvider = org.osmdroid.tileprovider.MapTileProviderBasic(
            applicationContext,
            weatherTileSource
        )
        val tilesOverlay = TilesOverlay(tileProvider, this)
        tilesOverlay.loadingBackgroundColor = android.graphics.Color.TRANSPARENT

        // Añadir la nueva capa
        mapView.overlays.add(tilesOverlay)
        capaActual = tilesOverlay

        // Refrescar mapa
        mapView.invalidate()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDetach()
    }
}

class WeatherTileSource(private val operacion: String) :
    org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase(
        "WeatherTiles",
        0, 18, 256, ".png",
        arrayOf("https://mapas-bqfqfpc7h6avb6bv.spaincentral-01.azurewebsites.net")
    ) {

    override fun getTileURLString(pMapTileIndex: Long): String {
        val zoom = org.osmdroid.util.MapTileIndex.getZoom(pMapTileIndex)
        val x = org.osmdroid.util.MapTileIndex.getX(pMapTileIndex)
        val y = org.osmdroid.util.MapTileIndex.getY(pMapTileIndex)

        return "${baseUrl[0]}/api/get_map?op=$operacion&z=$zoom&x=$x&y=$y"
    }
}