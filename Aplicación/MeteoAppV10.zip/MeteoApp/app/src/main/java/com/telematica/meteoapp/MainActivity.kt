package com.telematica.meteoapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler
import android.os.Looper

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // tu layout del splash

        // Esperar 2 segundos (2000 milisegundos)
        Handler(Looper.getMainLooper()).postDelayed({
            // Ir a la pantalla del formulario
            val intent = Intent(this, FormActivity::class.java)
            startActivity(intent)
            finish() // Cierra la pantalla de carga para que no se pueda volver atrás
        }, 2000)
    }
}
